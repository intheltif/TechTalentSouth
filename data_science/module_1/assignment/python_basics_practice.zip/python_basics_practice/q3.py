"""
Question 3 of Python Basics Practice from Module 1.

Author: Evert Ball
Date: 06/27/2020
"""
question = "What country are you from? >> "
answer = input(question)
print("I have heard that " + answer.strip() + " is a beautiful country!")
